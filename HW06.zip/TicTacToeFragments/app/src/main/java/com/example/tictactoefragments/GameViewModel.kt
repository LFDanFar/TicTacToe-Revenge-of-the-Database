package com.example.tictactoefragments

import androidx.lifecycle.ViewModel

class GameViewModel : ViewModel() {

    val game = Game()

}